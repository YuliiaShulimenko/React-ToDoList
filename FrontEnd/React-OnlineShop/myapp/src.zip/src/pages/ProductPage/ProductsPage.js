import React, { useEffect, useState } from 'react'
import ProductList from '../../components/ProductList/ProductList';
import { getProducts } from '../../request/getProducts'

export default function ProductPage() {
  const [products, setProducts] = useState([])
  useEffect(() => getProducts(setProducts), [])

  return (
    <div>
      ProductPage
      <ProductList products={products} />
    </div>
  )
}
