import React from 'react'

export default function Header() {
  return (
    <div>
      <a href='/'>Home</a>
      <a href='/products'>Products</a>
      {/* <a href='/products/product'>Products</a> */}
    </div>
  )
}
